package com.example.demosteps;

import com.example.demo.SpringIntegrationTest;
import com.example.demo.employee.*;
import com.atlassian.ta.wiremockpactgenerator.WireMockPactGenerator;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.springframework.beans.factory.annotation.Value;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import static com.github.tomakehurst.wiremock.client.WireMock.*;

public class EmployeeSteps extends SpringIntegrationTest {

	
	private static Response response;
    @Value("${app.employee.path}")
    private static String basePath;

    @Value("${app.employee.uri}")
    private static String baseURI; 

    
    @Before
    public void setUp() {
        wireMockPact =
                WireMockPactGenerator
                        .builder("Employee-consumer", "Employee-consumer")
                        .withRequestPathWhitelist(
                        		basePath+".*"
                        )
                        .build();
        wiremock.addMockServiceRequestListener(
                wireMockPact
        );
        if (activeProfile != null && activeProfile.equalsIgnoreCase("user") ) {
            wiremock.stubFor(get(urlMatching(basePath+".*"))
                    .willReturn(
                            aResponse()
                                    .withStatus(200)
                                    .withHeader("Content-Type", "application/json")
                                    .withBodyFile("Data/CreateEmployee.json")));
        }
    }
    
  

    @Given("user wants to \"([^\")\" an employee with the following attributes$")
    public static void create_update_employee(DataTable Employeedt)
     {
    	 List<Employee> employeeList = Employeedt.asList(Employee.class);

     }
    
    @Given("user wants to \"([^\")\" an employee with the following attributes as List$")
    public static void create_List_employee(DataTable Employeedt)
     {
    	 List<Employee> employeeList = Employeedt.asList(Employee.class);

     }
    @When("user saves the new employee$")
    public static void save_new_employee()
    {
    	String updateEmployeeUrl = baseURI + basePath;
    	Response response = request.accept(ContentType.JSON)
    		      .log()
    		      .all()
    		      .post(updateEmployeeUrl);
    }
    @Then("the status code is (\\d+)")
    public static void verifyResponseCode(long code) {
		if(response.statusCode() == code) {
			System.out.println("API Test is Successful and the status code "+code+" matches the expected code" + "Pass");
			
		}else {
			System.out.println("API Test is UnSuccessful and the status code "+code+" does not match the expected code" + response.statusCode());
			
		}
	}
    @When("employee already exists$")
    public static void employeeExist()
    {
    	String createEmployeeUrl = baseURI + basePath;
    	Response response = request.accept(ContentType.JSON)
    		      .log()
    		      .all()
    		      .post(createEmployeeUrl);
    }
    @When("user wants to get employee by employeename \"([^\")\"")
    public static void getemployeeid(String employeename)
    {
    	String getEmployeeByIdUrl = baseURI + basePath + employeename;
    	Response response = request.accept(ContentType.JSON)
    		      .log()
    		      .all()
    		      .get(getEmployeeByIdUrl);
    }
    @Then("following employee is returned$")
    public static void employee_returned(DataTable expectedEmployeeDt)
    {
    	List<Employee> actualEmployeeList = Arrays.asList(response.as(Employee.class));

        DataTable actualEmployeeDt = toEmployeeDataTable(actualEmployeeList);
        expectedEmployeeDt.unorderedDiff(actualEmployeeDt);

    }
    private static DataTable toEmployeeDataTable(List<Employee> employeeList) {
        List<List<String>> listOfList = new ArrayList<>();
        listOfList.add(Arrays.asList("id","employeename", "firstName", "lastName", "email", "password", "phone", "employeeStatus"));

        employeeList.forEach(e -> {
          Long id = e.getId();
          listOfList.add(
            Arrays.asList(id.toString(),e.getEmployeename(), e.getFirstName(), e.getLastName(),e.getEmail(),e.getPassword(),e.getPhone(),e.getEmployeeStatus())); 
    });

    return DataTable.create(listOfList);
  }
    
    @When("user saves the employee \"([^\")\"$")
    public static void save_employee(String employeename)
    {
    	String updateEmployeeUrl = baseURI + basePath+ employeename;;
    	Response response = request.accept(ContentType.JSON)
    		      .log()
    		      .all()
    		      .put(updateEmployeeUrl);
    }
    @When("user wants to delete employee by employeename \"([^\")\"")
    public static void deleteemployeeid(String employeename)
    {
    	String deleteEmployeeByIdUrl = baseURI + basePath + employeename;
    	Response response = request.accept(ContentType.JSON)
    		      .log()
    		      .all()
    		      .delete(deleteEmployeeByIdUrl);
    }
    @Given("user navigate to the Login page with Username and password")
    public static void login_employees(){

		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./application.properties")));
		} catch (IOException e) {
			
		}
		RestAssured.authentication = RestAssured.basic(
										prop.getProperty("UserName"), 
										prop.getProperty("Password"));
		String LoginEmployee = baseURI + basePath + "Login";
    	Response response = request.accept(ContentType.JSON)
    		      .log()
    		      .all()
    		      .get(LoginEmployee);
		
	}
    @Then("user logged out from application")
    public static void logout_employees() {
    	
    	String LogoutEmployee = baseURI + basePath + "Logout";
    	Response response = request.accept(ContentType.JSON)
    		      .log()
    		      .all()
    		      .get(LogoutEmployee);
}
    
     
    
    
}
