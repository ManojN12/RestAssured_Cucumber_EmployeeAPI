package com.example.demo.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

@RestController
@RequestMapping("/")
public class EmployeeController {
	
	private static Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@PostMapping(path = "/EmployeeApplication",consumes = {MediaType.APPLICATION_PDF_VALUE}, produces = {MediaType.APPLICATION_PDF_VALUE})
	 public ResponseEntity<InputStreamResource> EmployeeFinalMessage() throws IOException {
        
        ByteArrayInputStream bis = EmployeeController.EmployeeFinalMessagePDF_Format();
  
        return ResponseEntity
                .ok()
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
	 public static ByteArrayInputStream EmployeeFinalMessagePDF_Format() {
		        Document document = new Document();
		        ByteArrayOutputStream out = new ByteArrayOutputStream();
		        
		        try {
		          
		          PdfWriter.getInstance(document, out);
		            document.open();
		          
		            // Add Final Message to PDF file ->
		            document.add(new Paragraph("Hello, all API tests were successful'"));
		            document.close();
		       
		        }catch(DocumentException e) {
		          logger.error(e.toString());
		        }
		        
		    return new ByteArrayInputStream(out.toByteArray());
		  }
}
